/**
 * 
 */
package com.java9.miscellaneous;

/**
 * @author Eazy Bytes
 *
 */
public class PrivateMethodsImplementation implements PrivateMethodsInterface {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		PrivateMethodsImplementation pmi = new PrivateMethodsImplementation();
		System.out.println(pmi.addEvenNumbers(2,3,4,6));
		System.out.println(pmi.addOddNumbers(1,3,5,6));
	}

}
