/**
 * 
 */
package com.eazybytes.java8.lambda;

/**
 * @author Eazy Bytes
 *
 */
@FunctionalInterface
public interface ReturnMethodWithTwoParams {

	public int calculateAndReturn(int a, int b);
	
}
