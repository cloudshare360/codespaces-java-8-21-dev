/**
 * 
 */
package com.eazybytes.util;

/**
 * @author EazyBytes
 *
 */
@FunctionalInterface
public interface ProductInterface {

	Product getProduct(String name, int price);

}
