/**
 * 
 */
package com.eazybytes.java8.lambda;

/**
 * @author Eazy Bytes
 *
 */
@FunctionalInterface
public interface VoidMethodWithTwoParams {

	public void calculateAndPrint(int a, int b);
	
}
