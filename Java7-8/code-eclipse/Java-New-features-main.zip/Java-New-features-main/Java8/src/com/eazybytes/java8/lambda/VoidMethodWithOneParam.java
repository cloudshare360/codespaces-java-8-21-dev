/**
 * 
 */
package com.eazybytes.java8.lambda;

/**
 * @author Eazy Bytes
 *
 */
@FunctionalInterface
public interface VoidMethodWithOneParam {

	public void printInput(String input);
	
}
