/**
 * 
 */
package com.eazybytes.java8;

/**
 * @author EazyBytes
 *
 */
public interface StaticMain {

	public static void main(String[] args) {
		System.out.println("Running from the Static method inside interface");
	}
}
