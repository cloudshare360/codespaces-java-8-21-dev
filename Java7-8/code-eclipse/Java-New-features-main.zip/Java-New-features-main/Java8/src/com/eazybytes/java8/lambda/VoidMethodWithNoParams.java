/**
 * 
 */
package com.eazybytes.java8.lambda;

/**
 * @author Eazy Bytes
 *
 */
@FunctionalInterface
public interface VoidMethodWithNoParams {

	public void printHello();
	
	
}
